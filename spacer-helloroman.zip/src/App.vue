<template>
  <div class="app">
      <div>
        <router-link to="/">spacer</router-link>
        <router-link to="/about">about</router-link>
      </div>
    <router-view />
  </div>
</template>

<style lang="scss" scoped>

